﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra
{
    public class AnimalCare
    {
        private Dictionary<string, int> foodStock;

        public AnimalCare()
        {
            foodStock = new Dictionary<string, int>();
        }

        public void AddFood(string foodType, int quantity)
        {
            if (foodStock.ContainsKey(foodType))
            {
                foodStock[foodType] += quantity;
            }
            else
            {
                foodStock[foodType] = quantity;
            }
        }

        public int GetFoodStock(string foodType)
        {
            return foodStock.ContainsKey(foodType) ? foodStock[foodType] : 0;
        }

        public string DisplayFoodStock()
        {
            StringBuilder result = new StringBuilder();

            if (foodStock.Count == 0)
            {
                result.AppendLine("Food stock is empty.");
            }
            else
            {
                result.AppendLine("Food stock:");
                foreach (var stock in foodStock)
                {
                    result.AppendLine($"{stock.Key}: {stock.Value} units");
                }
            }

            return result.ToString();
        }

    }
}
