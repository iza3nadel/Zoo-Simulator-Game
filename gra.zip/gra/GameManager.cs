﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using gra.Seasons;
using gra.Animals;
using System.Data;
using gra.Events;
using Microsoft.VisualBasic;

namespace gra
{
    public class GameManager
    {
        // przykładowy level 1

        private ZooBoxOffice boxOffice;
        private AnimalCare animalCare;
        private List<Enclosure> enclosures;
        private MainShop shop;
        private Health health;
        private Composite animals;
        private Composite mammals;
        private Composite birds;
        private Composite reptiles;
        private Composite fishes;
        private Season currentSeason;
        private int dailyActions;
        private List<Event> events;
        private Event normalDay;
        private Random random;
        private ManagerSupport support;


        public GameManager()
        {
            boxOffice = new ZooBoxOffice(initialBudget: 15000, ticketPrice: 10);
            animalCare = new AnimalCare();
            health = new Health(animalCare, boxOffice);
            animals = new Composite("All Animals");
            mammals = new Composite("Mammals");
            birds = new Composite("Birds");
            reptiles = new Composite("Reptiles");
            fishes = new Composite("Fishes");
            shop = new MainShop(boxOffice, animalCare, animals, mammals, birds, reptiles, fishes);
            enclosures = new List<Enclosure>();
            currentSeason = new Spring(); // Gra zaczyna się na wiosnę
            dailyActions = 3; // Liczba akcji dziennych
            events = new List<Event>
            {
                new Epidemic(),
                new Birthday()
            };
            normalDay = new NormalDay();
            random = new Random();
            support = new ManagerSupport(enclosures, shop, animals, health, boxOffice, events, random, animalCare, dailyActions);
        }

        string file1 = File.ReadAllText(@"C:\\Users\\trzna\\OneDrive\\Pulpit\\uni\\c#\\3_semestr\\gra\\welcome.txt");
        string file2 = File.ReadAllText(@"C:\\Users\\trzna\\OneDrive\\Pulpit\\uni\\c#\\3_semestr\\gra\\options.txt");
        string file3 = File.ReadAllText(@"C:\\Users\\trzna\\OneDrive\\Pulpit\\uni\\c#\\3_semestr\\gra\\gameOver.txt");



        public void NewDay()
        {
            Console.WriteLine(file1);

            while (support.CheckGameEnd()) // Pętla reprezentująca kolejne dni
            {
                dailyActions = 3; // Reset liczby akcji na początku dnia

                Console.WriteLine("\n-------------------------- New Day --------------------------");
                Console.WriteLine($"Initial budget: {boxOffice.GetBudget()}");
                Console.WriteLine($"Current season: {currentSeason.Name}");

                string weather = currentSeason.GetWeather();
                Console.WriteLine($"Today's Weather: {weather}");
                Console.WriteLine(support.TriggerRandomEvent());
                Console.WriteLine(boxOffice.CalculateDailyIncome(weather));
                Console.WriteLine(support.DisplayProgressBar());

                while (dailyActions > 0) // Pętla na akcje w ciągu dnia
                {
                    Console.WriteLine($"\nRemaining Actions Today: {dailyActions}");
                    Console.WriteLine(file2);
                    Console.Write("Enter your choice: ");

                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":
                            Console.WriteLine("\nAnimals available:");
                            Console.WriteLine(Composite.DisplayAllSpecies());

                            Console.Write("Enter the species you want to buy: ");
                            string species = Console.ReadLine();
                            (string s, bool b) result4 = shop.ChcekSpecies(species);
                            Console.WriteLine(result4.s);
                            if (!result4.b){break;}

                            Console.Write("Enter the name of the animal: ");
                            string name = Console.ReadLine();
                            Console.WriteLine("Select an enclosure for the animal:");
                            Console.WriteLine(support.DisplayEnclosures());

                            Console.Write("Enter the enclosure number: ");
                            int.TryParse(Console.ReadLine(), out int enclosureIndex);
                            (bool b, string s) result3 = support.BuyAnimal(enclosureIndex - 1, species, name);
                            support.DecreaseActions(result3.b, ref dailyActions);
                            Console.WriteLine(result3.s);
                            Console.WriteLine("Press Enter");
                            Console.ReadKey();
                            
                            break;

                        case "2":
                            (bool b, string s) result = support.BuildEnclosure();
                            support.DecreaseActions(result.b, ref dailyActions);
                            Console.WriteLine(result.s);
                            Console.WriteLine("Press Enter");
                            Console.ReadKey();
                            
                            break;

                        case "3":
                            Console.Write("Enter the quantity: ");
                            int.TryParse(Console.ReadLine(), out int quantity);

                            Console.Write("Enter the species of an animal that eats this food: ");
                            string species2 = Console.ReadLine();
                            support.DecreaseActions(support.BuyFood(species2, quantity), ref dailyActions);
                            Console.WriteLine("Press Enter");
                            Console.ReadKey();
                            
                            break;

                        case "4":
                            Console.WriteLine("\n--- Treat an Animal ---");
                            List<Animal> allAnimals = animals.GetAllAnimals();
                            Console.WriteLine(support.DisplayAnimals());

                            Console.Write("Enter the number of the animal you want to treat: ");
                            int.TryParse(Console.ReadLine(), out int choice2);
                            if (support.Check(choice2, animals.GetAllAnimals())) {break;}
                            Animal chosen = allAnimals[choice2 - 1];
                            (string pharse, bool answer) result2 = health.Treat(chosen);
                            support.DecreaseActions(result2.answer, ref dailyActions);
                            Console.WriteLine(result2.pharse);
                            Console.WriteLine("Press Enter");
                            Console.ReadKey();
                            
                            break;
                        case "5":
                            Console.WriteLine("\n--- Feed an Animal ---");
                            List<Animal> allAnimals2 = animals.GetAllAnimals();
                            Console.WriteLine(support.DisplayAnimals());

                            Console.Write("Enter the number of the animal you want to feed: ");
                            int.TryParse(Console.ReadLine(), out int choice4);
                            if (support.Check(choice4, animals.GetAllAnimals())) {break;}
                            Animal chosen1 = allAnimals2[choice4 - 1];
                            (string pharse, bool answer) result5 = health.Feed(chosen1);
                            support.DecreaseActions(result5.answer, ref dailyActions);
                            Console.WriteLine(result5.pharse); 
                            Console.WriteLine("Press Enter");
                            Console.ReadKey();
                            
                            break;

                        case "6":
                            dailyActions = 0;
                            break;

                        default:
                            Console.WriteLine("Invalid choice. Try again.");
                            break;
                    }
                }

                currentSeason = currentSeason.ChangeSeason();
                Console.Clear();
                // Wyświetla statystyki na koniec dnia
                animals.ExecuteEvent(normalDay);

                support.RemoveAnimals(enclosures);

                Console.WriteLine(support.EndDay());

                Console.WriteLine("Press Enter to start a new day...");
                Console.ReadLine();
            }

            Console.WriteLine(file3);
            Console.WriteLine($"Final Budget: {boxOffice.GetBudget()}");
            Console.WriteLine($"Extinction Points: {animals.ExtinctionPoints}");
            Console.WriteLine("Thank you for playing!");
        }
    }
}
