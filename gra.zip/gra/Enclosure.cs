﻿using gra.Animals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra
{
    public class Enclosure
    {
        private List<Animal> animals = new List<Animal>();
        private string allowedSpecies;
        private int animalCount = 0;


        public bool AddAnimal(Animal animal)
        {
            if (animals.Count == 0)
            {
                // Jeśli wybieg jest pusty, ustawiam dopuszczony gatunek
                allowedSpecies = animal.GetSpecies();
                animals.Add(animal);
                animalCount++;
                return true;
            }
            else if (animal.GetSpecies() == allowedSpecies)
            {
                // Dodaje zwierzę tylko, jeśli gatunek się zgadza
                animals.Add(animal);
                animalCount++;
                return true;
            }
            else
            {
                return false;
            }
        }

        public string GetSpecies()
        {
            return allowedSpecies;
        }
        public int GetAnimalCount()
        {
            return animalCount;
        }

        public string RemoveUnhealthyAnimals()
        {
            for (int i = animals.Count - 1; i >= 0; i--) 
            {
                Animal animal = animals[i];
                if (animal.Hunger >= 20 || animal.Health <= 0)
                {
                    
                    animals.RemoveAt(i);
                    animalCount--;
                    return $"{animal.GetSpecies()} named {animal.Name} has been removed due to hunger or health issues.";
                }
                
            }
            return null;
        }
    }
}
