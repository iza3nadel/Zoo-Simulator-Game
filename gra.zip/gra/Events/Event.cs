﻿using gra.Animals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Events
{
    public abstract class Event
    {
        public abstract void Execute(Animal animal);
        public abstract void ApplyToZooBoxOffice(ZooBoxOffice boxOffice);
    }
}
