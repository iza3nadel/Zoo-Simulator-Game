﻿using gra.Animals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Events
{
    public class Birthday : Event
    {
        private int hungerIncrease = 1; // Liczba punktów głodu, które zostaną dodane
        private int incomeIncreasePercentage = 10; // Procentowy wzrost przychodu

        public override void Execute(Animal animal)
        {
            animal.Hunger += hungerIncrease; 
        }

        public override void ApplyToZooBoxOffice(ZooBoxOffice boxOffice)
        {
            boxOffice.ApplyIncomeIncrease(incomeIncreasePercentage);
        }
    }
}
