﻿using gra.Animals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Events
{
    public class NormalDay : Event
    {
        private int incomeReductionPercentage = 0;
        public override void Execute(Animal animal)
        {
            animal.Health--; 
            animal.Hunger++;

        }
        public override void ApplyToZooBoxOffice(ZooBoxOffice boxOffice)
        {
            boxOffice.ApplyIncomeReduction(incomeReductionPercentage);
        }
    }
}
