﻿using gra.Animals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Events
{
    public class Epidemic : Event
    {
        private int incomeReductionPercentage = 10;
        public override void Execute(Animal animal)
        {
            animal.Health -= 2; 
            
        }

        public override void ApplyToZooBoxOffice(ZooBoxOffice boxOffice)
        {
            boxOffice.ApplyIncomeReduction(incomeReductionPercentage);
        }
    }
}
