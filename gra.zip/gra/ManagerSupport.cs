﻿using gra.Animals;
using gra.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra
{
    public class ManagerSupport
    {
        private List<Enclosure> enclosures;
        private MainShop shop;
        private Composite animals;
        private Health health;
        private ZooBoxOffice boxOffice;
        private List<Event> events;
        private Random random;
        private AnimalCare animalCare;
        private int dailyActions;
        public ManagerSupport(List<Enclosure> enclosures,MainShop shop,Composite animals,Health health,ZooBoxOffice boxOffice,List<Event> events,Random random,AnimalCare animalCare,int dailyActions)
        {
            this.enclosures = enclosures;
            this.shop = shop;
            this.animals = animals;
            this.health = health;
            this.boxOffice = boxOffice;
            this.events = events;
            this.random = random;
            this.animalCare = animalCare;
            this.dailyActions = dailyActions;
        }
        public string RemoveAnimals(List<Enclosure> enclosures)
        {
            StringBuilder result = new StringBuilder();
            foreach (var enclosure in enclosures)
            {
                result.AppendLine(enclosure.RemoveUnhealthyAnimals());
            }
            return result.ToString();

        }

        public void DecreaseActions(bool success, ref int actions)
        {
            if (success)
            {
                actions--;
            }
        }


        public (bool, string) BuyAnimal(int enclosureIndex, string species, string name)
        {
            if (enclosureIndex < 0 || enclosureIndex >= enclosures.Count)
            {
                return (false, "Invalid enclosure index.");
            }

            (string message, bool success) result = shop.BuyAnimal(species, enclosures[enclosureIndex], name);

            if (result.success)
            {
                return (true, result.message);
            }

            return (false, result.message);
        }

        public (bool, string) BuildEnclosure()
        {
            (Enclosure e, string s) newEnclosure = shop.BuildEnclosure();
            if (newEnclosure.e != null)
            {
                enclosures.Add(newEnclosure.e);
                return (true, newEnclosure.s);
            }
            return (false, newEnclosure.s);
        }

        public bool BuyFood(string species, int quantity)
        {
            (string message, bool success) result = shop.BuyFood(species, quantity);
            if (result.success)
            {
                return true;
            }
            return false;

        }

        public string DisplayAnimals()
        {
            List<Animal> allAnimals = animals.GetAllAnimals();
            if (allAnimals.Count == 0)
            {
                return "There are no animals in the zoo to treat.";
            }
            else
            {
                StringBuilder result = new StringBuilder();
                for (int i = 0; i < allAnimals.Count; i++)
                {
                    Animal animal = allAnimals[i];
                    result.AppendLine($"{i + 1}. {animal.GetSpecies()} - Health: {animal.Health}, Hunger: {animal.Hunger}");
                }
                return result.ToString();
            }
        }

        public string DisplayEnclosures()
        {
            var result = new StringBuilder();

            result.AppendLine("\n-------------------------- List of Enclosures --------------------------");
            if (enclosures.Count == 0)
            {
                result.AppendLine("No enclosures have been created yet.");
                return result.ToString();
            }

            for (int i = 0; i < enclosures.Count; i++)
            {
                var enclosure = enclosures[i];
                string animalType = enclosure.GetSpecies(); 
                int animalCount = enclosure.GetAnimalCount(); 

                if (animalCount > 0)
                {
                    result.AppendLine($"Enclosure {i + 1}: {animalType} ({animalCount} animal(s))");
                }
                else
                {
                    result.AppendLine($"Enclosure {i + 1}: Empty");
                }
            }

            return result.ToString();
        }

        public string EndDay()
        {
            StringBuilder result = new StringBuilder();

            result.AppendLine("\n---------------------- End of Day Statistics ----------------------");

            result.AppendLine($"Current Budget: {boxOffice.GetBudget()}");

            List<Animal> allAnimals = animals.GetAllAnimals();

            if (allAnimals.Count == 0)
            {
                result.AppendLine("There are no animals in the zoo.");
            }
            else
            {
                result.AppendLine("Animals in the Zoo:");
                foreach (var animal in allAnimals)
                {
                    result.AppendLine($"{animal.Name} ({animal.GetSpecies()}) - Hunger: {animal.Hunger}, Health: {animal.Health}");
                }
            }

            result.AppendLine("\n-------------------------- Food Stock --------------------------");
            result.AppendLine(animalCare.DisplayFoodStock());

            dailyActions = 3; // Resetowanie liczby dziennych akcji
            result.AppendLine("\nThe day has ended. Actions have been reset for the next day.");

            result.AppendLine(DisplayProgressBar()); 

            return result.ToString();
        }


        public string TriggerRandomEvent()
        {
            if (random.Next(100) < 20) // Szansa 20% na wystąpienie wydarzenia
            {
                Event selectedEvent = events[random.Next(events.Count)];

                // Zastosowanie efektów wydarzenia na zwierzętach
                animals.ExecuteEvent(selectedEvent);

                // Zastosowanie efektów wydarzenia na finanse zoo
                selectedEvent.ApplyToZooBoxOffice(boxOffice);

                return $"\n------------------- Unexpected Event: {selectedEvent.GetType().Name} ---------------\n";
            }
            return "";
        }

        public string DisplayProgressBar()
        {

            const int maxBudgetPoints = 100000; // Cel finansowy
            const int maxExtinctionPoints = 30; // Maksymalne punkty za zagrożone gatunki

            // Obecny stan gracza
            int currentBudget = boxOffice.GetBudget();
            int currentExtinctionPoints = animals.ExtinctionPoints;

            // Obliczenie progresu jako procent
            double budgetProgress = Math.Min(1.0, (double)currentBudget / maxBudgetPoints);
            double extinctionProgress = Math.Min(1.0, (double)currentExtinctionPoints / maxExtinctionPoints);
            double totalProgress = (budgetProgress + extinctionProgress) / 2; // Średnia dwóch celów

            // Pasek postępu
            const int progressBarWidth = 30; 
            int progressBlocks = (int)(totalProgress * progressBarWidth);

            var builder = new StringBuilder();
            builder.AppendLine("\n-------------------- Progress to Victory --------------------");
            builder.Append("             [");
            builder.Append(new string('#', progressBlocks)); // Wypełniona część paska
            builder.Append(new string('-', progressBarWidth - progressBlocks)); // Pusta część paska
            builder.Append($"] {totalProgress:P0}");

            return builder.ToString();
        }

        public bool CheckGameEnd()
        {
            if (boxOffice.GetBudget() / 1000 + animals.ExtinctionPoints > 130)
            {
                return false;
            }
            return true;
        }

        public bool Check(int choice, List<Animal> allAnimals)
        {
            return choice < 0 || choice > allAnimals.Count;
        }
    }
}
