﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using gra.Animals;

namespace gra
{
    public class Health
    {
        private const int maxHealth = 20;
        private const int minHunger = 0;
        private AnimalCare animalCare;
        private ZooBoxOffice boxOffice;

        public Health(AnimalCare animalCare, ZooBoxOffice boxOffice)
        {
            this.animalCare = animalCare;
            this.boxOffice = boxOffice; 
        }

        public (string, bool) Feed(Animal animal)
        {
            if (animal == null)
            {
                return ($"Incorrectly selected animal", false);
            }

            if (animal.Hunger <= minHunger)
            {
                return ($"{animal.Name} is full.", false);
            }

            string requiredFood = animal.FoodType;

            if (boxOffice.DeductBudget(animal.FoodCost))
            {
                animalCare.AddFood(requiredFood, -1);
                animal.Hunger = Math.Min(minHunger, animal.Hunger - 1);
                return ($"{animal.Name} has been fed. Hunger decreased to {animal.Hunger}.", true);
            }
            else
            {
                return ($"No food available for this species: {animal.GetSpecies()}", false);
            }

            
        }
        public (string, bool) Treat(Animal animal)
        {
            if (animal == null)
            {
                return ($"Incorrectly selected animal", false);
            }

            if (animal.Health >= maxHealth)
            {
                return ($"{animal.Name} is perfectly healthy.", false);
            }

            string requiredMedicine = animal.RequiredMedicine;

            if (boxOffice.DeductBudget(animal.MedicineCost))
            {
                animal.Health = Math.Min(maxHealth, animal.Health + 1);
                return ($"{animal.Name} has been treated. Health increased to {animal.Health}.", true);
            }
            else
            {
                return ($"Not enough budget to buy {animal.RequiredMedicine}. Required: {animal.MedicineCost}, Available: {boxOffice.GetBudget()}.", false);
            }


        }

    }
}
