﻿using gra.Animals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace gra
{
    public class MainShop
    {
        private ZooBoxOffice boxOffice;
        private AnimalCare animalCare;
        private Composite animals;
        private Composite mammals;
        private Composite birds;
        private Composite reptiles;
        private Composite fishes;

        public MainShop(ZooBoxOffice zooBoxOffice, AnimalCare animalCare, Composite animals, Composite mammals, Composite birds, Composite reptiles, Composite fishes)
        {
            this.boxOffice = zooBoxOffice;
            this.animalCare = animalCare;
            this.animals = animals;
            this.mammals = mammals;
            this.birds = birds;
            this.reptiles = reptiles;
            this.fishes = fishes;
        }

        private List<string> availableAnimals = new List<string>
        {
            "elephant", "giraffe", "turtle", "crocodile", "parrot", "flamingo", "zebrasoma", "nemo"
        };

        public (string, bool) BuyFood(string species, int quantity)
        {
            if (quantity <= 0)
            {
                return ("Quantity must be greater than zero.", false);
            }

            // Znajduje odpowiednie zwierzę na podstawie gatunku
            Animal animal = animals.FindBySpecies(species);
            if (animal == null)
            {
                return ($"Animal species '{species}' not found.", false);
            }

            int totalCost = quantity * animal.FoodCost;

            if (boxOffice.DeductBudget(totalCost))
            {
                animalCare.AddFood(animal.FoodType, quantity);
                return ($"Bought {quantity} units of {animal.FoodType} for {species}. Total cost: {totalCost}", true);
            }
            else
            {
                return ($"Not enough budget to buy {quantity} units of {animal.FoodType} for {species}. Required: {totalCost}, Available: {boxOffice.GetBudget()}.", false);
            }
        }

        public (string, bool) ChcekSpecies(string species)
        {
            if (!availableAnimals.Contains(species))
            {
                return ($"The species '{species}' is not available in the shop.", false);
            }
            return ("", true);
        }

        public (string, bool) BuyAnimal(string species, Enclosure enclosure, string name)
        {
            Animal animal = null;
            switch (species.ToLower())
            {
                case "elephant":
                    animal = new Elephant(name);
                    animals.Add(animal);
                    mammals.Add(animal);
                    break;

                case "giraffe":
                    animal = new Giraffe(name);
                    animals.Add(animal);
                    mammals.Add(animal);
                    break;
                case "crocodile":
                    animal = new Crocodile(name);
                    animals.Add(animal);
                    reptiles.Add(animal);
                    break;
                case "turtle":
                    animal = new Turtle(name);
                    animals.Add(animal);
                    reptiles.Add(animal);
                    break;
                case "flamingo":
                    animal = new Flamingo(name);
                    animals.Add(animal);
                    birds.Add(animal);
                    break;
                case "parrot":
                    animal = new Parrot(name);
                    animals.Add(animal);
                    birds.Add(animal);
                    break;
                case "zebrasoma":
                    animal = new Zebrasoma(name);
                    animals.Add(animal);
                    fishes.Add(animal);
                    break;
                case "nemo":
                    animal = new Nemo(name);
                    animals.Add(animal);
                    fishes.Add(animal);
                    break;

            }

            int cost = animal.Cost;

            if (boxOffice.DeductBudget(cost))
            {
                if (!enclosure.AddAnimal(animal))
                {
                    boxOffice.SetBudget(boxOffice.GetBudget() + cost); // Zwracamy koszt do budżetu
                    return ($"Animal could not be added to the enclosure because it either does not exist or already contains another species.", false);
                }
            }
            else
            {
                return ($"Not enough budget to buy the {species}. Required: {cost}, Available: {boxOffice.GetBudget()}", false);
            }
            return ($"{animal.GetSpecies()} successfully bought", true);
        }

        public (Enclosure, string) BuildEnclosure()
        {
            int cost = 1000;

            if (boxOffice.DeductBudget(cost))
            {
                Enclosure newEnclosure = new Enclosure();
                return (newEnclosure, $"Enclosure has been successfully built for {cost}.");
            }
            else
            {
                return (null, $"Not enough budget to build the enclosure. Required: {cost}, Available: {boxOffice.GetBudget()}");
            }
        }
    }
}
