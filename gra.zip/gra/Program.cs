﻿using System.Reflection.Emit;
using gra.Seasons;

namespace gra
{
    public class Program
    {
        static void Main(string[] args)
        {
            

            GameManager gameLevels = new GameManager();
            
            // Symulacja nowego dnia
            gameLevels.NewDay();

        }



    }

    
}
