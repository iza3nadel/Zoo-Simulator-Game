﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using gra.Events;

namespace gra
{
    public class ZooBoxOffice
    {
        private int budget; 
        private int ticketPrice; 
        private Random random = new Random();
        private int incomeReductionPercentage = 0;
        private int incomeIncreasePercentage = 0; // Wzrost przychodów w procentach

        public ZooBoxOffice(int initialBudget, int ticketPrice)
        {
            this.budget = initialBudget;
            this.ticketPrice = ticketPrice;
        }

        public string CalculateDailyIncome(string weather)
        {
            int visitors = GetVisitors(weather);
            int dailyIncome = visitors * ticketPrice;

            // Uwzględnienie redukcji przychodów spowodowanej wydarzeniem
            dailyIncome -= (dailyIncome * incomeReductionPercentage) / 100;
            dailyIncome += (dailyIncome * incomeIncreasePercentage) / 100;

            budget += dailyIncome;
            return $"Daily income: {dailyIncome}. Available budget: {budget}";
        }

        private int GetVisitors(string weather)
        {
            // Liczba odwiedzających zależna od pogody
            switch (weather)
            {
                case "Sunny":
                    return random.Next(200, 500); // Więcej odwiedzających w słoneczny dzień
                case "Rainy":
                    return random.Next(50, 150); // Mniej odwiedzających w deszczowy dzień
                case "Stormy":
                    return random.Next(10, 50); // Bardzo mało odwiedzających w burzowy dzień
                case "Snowy":
                    return random.Next(20, 100); // Średnia liczba odwiedzających w śnieżny dzień
                case "Cloudy":
                    return random.Next(100, 300); // Umiarkowana liczba odwiedzających
                default:
                    return 0; 
            }
        }

        public int GetBudget()
        {
            return budget;
        }

        public void SetBudget(int newBudget)
        {
            budget = newBudget;
        }

        public bool DeductBudget(int amount)
        {
            if (budget >= amount)
            {
                budget -= amount;
                return true;
            }
            else
            {
                return false;
            }
        }
        public void ApplyIncomeReduction(int percentage)
        {
            incomeReductionPercentage = percentage;
        }
        public void ResetIncomeReduction()
        {
            incomeReductionPercentage = 0;
        }

        public void ApplyIncomeIncrease(int percentage)
        {
            incomeIncreasePercentage = percentage;
        }
        public void ResetIncomeIncrease()
        {
            incomeIncreasePercentage = 0;
        }

    }
}
