﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Animals
{
    public abstract class Fish : Animal
    {
        public Fish(string name)
        : base(name)
        {
        }

        public override string FoodType => "Fish Food";

        public override int FoodCost => 20;

        public override string RequiredMedicine => "Fish Remedy";
        public override int MedicineCost => 100;
    }
}
