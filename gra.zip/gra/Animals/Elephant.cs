﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Animals
{
    public class Elephant : Mammal
    {
    
        public Elephant(string name)
        : base(name) 
        {
        }

        public override int Cost { get; } = 5000; 
        public override int ExtinctionPoints { get; } = 10;
        public override string GetSpecies()
        {
            return "Elephant";
        }
    }
}
