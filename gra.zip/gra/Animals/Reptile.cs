﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Animals
{
    public abstract class Reptile : Animal
    {
        public Reptile(string name)
        : base(name)
        {
        }

        public override string FoodType => "Reptile Food";

        public override int FoodCost => 60;

        public override string RequiredMedicine => "Reptile Remedy";
        public override int MedicineCost => 300;
    }
}
