﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Animals
{
    public class Crocodile : Reptile
    {
        public Crocodile(string name)
        : base(name)
        {
        }

        public override int Cost { get; } = 2000; 
        public override int ExtinctionPoints { get; } = 4;

        public override string GetSpecies()
        {
            return "Crocodile";
        }
    }
}
