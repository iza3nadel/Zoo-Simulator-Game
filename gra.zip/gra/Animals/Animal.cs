﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Animals
{
    public abstract class Animal
    {
        public int Health { get; set; }
        public int Hunger { get; set; }
        public abstract int Cost { get; }
        public abstract string FoodType { get; }
        public abstract int FoodCost { get; }
        public abstract string RequiredMedicine { get; }
        public abstract int MedicineCost { get; }
        public abstract int ExtinctionPoints { get; }
        public string Name { get; set; }


        public Animal(string name = "Unnamed")
        {
            Name = name;
            Health = 10;
            Hunger = 10;
        }

        public abstract string GetSpecies();

    }
}
