﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Animals
{
    public class Parrot : Bird
    {
        public Parrot(string name)
        : base(name)
        {
        }

        public override int Cost { get; } = 4000; 
        public override int ExtinctionPoints { get; } = 7;
        public override string GetSpecies()
        {
            return "Parrot";
        }
    }
}
