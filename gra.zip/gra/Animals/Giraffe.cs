﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Animals
{
    public class Giraffe : Mammal
    {
        public Giraffe(string name)
        : base(name) 
        {
        }

        public override int Cost { get; } = 3000;
        public override int ExtinctionPoints { get; } = 5;
        public override string GetSpecies()
        {
            return "Giraffe";
        }

    }
}
