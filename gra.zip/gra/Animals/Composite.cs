﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using gra.Events;

namespace gra.Animals
{
    public class Composite : Animal
    {
        private List<Animal> children = new List<Animal>(); 

        public Composite(string name)
            : base(name)
        {
        }

      
        public void Add(Animal component)
        {
            children.Add(component);
        }

  
        public void Remove(Animal component)
        {
            children.Remove(component);
        }


        public override int Cost
        {
            get
            {
                int totalCost = 0;
                foreach (var child in children)
                {
                    totalCost += child.Cost; 
                }
                return totalCost;
            }
        }

        public override string FoodType
        {
            get
            {

                var foodTypes = new HashSet<string>();
                foreach (var child in children)
                {
                    foodTypes.Add(child.FoodType);
                }
                return string.Join(", ", foodTypes); 
            }
        }

        public override int FoodCost
        {
            get
            {
                int totalFoodCost = 0;
                foreach (var child in children)
                {
                    totalFoodCost += child.FoodCost; 
                }
                return totalFoodCost;
            }
        }

        public override string RequiredMedicine
        {
            get
            {

                var medicines = new HashSet<string>();
                foreach (var child in children)
                {
                    medicines.Add(child.RequiredMedicine);
                }
                return string.Join(", ", medicines); 
            }
        }

        public override int MedicineCost
        {
            get
            {
                int totalPoints = 0;
                foreach (var child in children)
                {
                    totalPoints += child.ExtinctionPoints; 
                }
                return totalPoints;
            }
        }
        public override int ExtinctionPoints
        {
            get
            {
                int totalPoints = 0;
                foreach (var child in children)
                {
                    totalPoints += child.ExtinctionPoints; 
                }
                return totalPoints;
            }

        }


        public override string GetSpecies()
        {
            foreach (var child in children)
            {
                child.GetSpecies(); 
            }
            return $"Grupa: {Name}"; 
        }

        public void ExecuteEvent(Event e)
        {

            foreach (var child in children)
            {
                if (child is Composite composite)
                {
                    composite.ExecuteEvent(e); 
                }
                else
                {
                    e.Execute(child); 
                }
            }
        }
        public Animal FindBySpecies(string species)
        {
            foreach (var child in children) 
            {
                if (child is Animal animal && animal.GetSpecies().Equals(species, StringComparison.OrdinalIgnoreCase))
                {
                    return animal;
                }
                else if (child is Composite composite)
                {
                    Animal found = composite.FindBySpecies(species);
                    if (found != null)
                    {
                        return found;
                    }
                }
            }
            return null;
        }
        public List<Animal> GetAllAnimals()
        {
            List<Animal> allAnimals = new List<Animal>();

            for (int i = children.Count - 1; i >= 0; i--) 
            {
                if (children[i] is Animal animal)
                {
                    if (animal.Hunger >= 20 || animal.Health <= 0)
                    {
                        children.RemoveAt(i);
                    }
                    else
                    {
                        allAnimals.Add(animal);
                    }
                }
                
            }

            return allAnimals;
        }

        public static string DisplayAllSpecies()
        {
            StringBuilder result = new StringBuilder(); 

            var animalsGroupedByType = Assembly.GetExecutingAssembly()
                .GetTypes()
                .Where(t => t.IsSubclassOf(typeof(Animal)) && !t.IsAbstract && t.BaseType != typeof(Animal)) // Wykluczam Animal oraz klasy abstrakcyjne
                .GroupBy(t => t.BaseType) // Grupa według typu bazowego
                .ToDictionary(g => g.Key, g => g.ToList());

            // Iterowanie po każdej grupie (gatunkach) i tworzenie wyniku
            foreach (var group in animalsGroupedByType)
            {
                // Dodanie nazwy gatunku (np. Mammal, Reptile itp.)
                result.AppendLine($"{group.Key.Name}s:");

                // Iterowanie po każdej klasie w tej grupie
                foreach (var type in group.Value)
                {
                    // Tworzenie instancji obiektu danej klasy
                    var animalInstance = Activator.CreateInstance(type, "Test") as Animal;

                    if (animalInstance != null)
                    {
                        result.AppendLine($"\tSpecies: {animalInstance.GetSpecies()}");
                        result.AppendLine($"\tCost: {animalInstance.Cost}");
                        result.AppendLine($"\tExtinction Points: {animalInstance.ExtinctionPoints}");
                        result.AppendLine();
                    }
                }
            }

            return result.ToString();
        }

        

    }
}
