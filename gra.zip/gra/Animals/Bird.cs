﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Animals
{
    public abstract class Bird : Animal
    {
        public Bird(string name)
        : base(name)
        {
        }

        public override string FoodType => "Bird Food";

        public override int FoodCost => 40;

        public override string RequiredMedicine => "Bird Remedy";
        public override int MedicineCost => 200;
    }
}
