﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Animals
{
    public class Flamingo : Bird
    {
        public Flamingo(string name)
        : base(name)
        {
        }

        public override int Cost { get; } = 1500; 
        public override int ExtinctionPoints { get; } = 3;
        public override string GetSpecies()
        {
            return "Flamingo";
        }
    }
}
