﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Animals
{
    public class Zebrasoma : Fish
    {
        public Zebrasoma(string name)
        : base(name)
        {
        }

        public override int Cost { get; } = 1200; 
        public override int ExtinctionPoints { get; } = 2;
        public override string GetSpecies()
        {
            return "Zebrasoma";
        }
    }
}
