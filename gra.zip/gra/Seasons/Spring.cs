﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Seasons
{
    public class Spring : Season
    {
        public Spring()
        {
            Name = "Spring";
            daysInCurrentSeason = 0;
            WeatherProbabilities = new Dictionary<string, double>
            {
                { "Sunny", 0.4 },  // 40% na słoneczny dzień
                { "Rainy", 0.3 },  // 30% na deszczowy dzień
                { "Stormy", 0.2 }, // 20% na burzowy dzień
                { "Cloudy", 0.1 }  // 10% na pochmurny dzień
            };
        }
        
    }
}
