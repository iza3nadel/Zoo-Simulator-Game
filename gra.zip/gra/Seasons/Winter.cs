﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Seasons
{
    public class Winter : Season
    {
        public Winter()
        {
            Name = "Winter";
            daysInCurrentSeason = 0;
            WeatherProbabilities = new Dictionary<string, double>
            {
                { "Snowy", 0.5 },  // 50% na śnieżny dzień
                { "Rainy", 0.3 },  // 30% na deszczowy dzień
                { "Cloudy", 0.2 }  // 20% na pochmurny dzień
            };
        }

    }
}
