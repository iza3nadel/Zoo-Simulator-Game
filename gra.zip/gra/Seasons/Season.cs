﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Seasons
{
    public class Season
    {
        protected Dictionary<string, double> WeatherProbabilities = new Dictionary<string, double>();

        private static Random random = new Random();
        public string Name { get; protected set; }
        protected int daysInCurrentSeason;

        public Season GetNextSeason()
        {
            if (this is Spring)
                return new Summer();
            else if (this is Summer)
                return new Autumn();
            else if (this is Autumn)
                return new Winter();
            else if (this is Winter)
                return new Spring();

            return null; // Zabezpieczenie w przypadku błędów
        }
        public Season ChangeSeason()
        {
            daysInCurrentSeason++;

            if (daysInCurrentSeason >= 3)
            {
                daysInCurrentSeason = 0;
                return GetNextSeason(); // Zwracamy następny sezon
            }

            return this; // Zwróć ten sam sezon, jeśli nie trzeba zmieniać
        }
        public string GetWeather()
        {
            double roll = random.NextDouble();
            double cumulative = 0.0;

            foreach (var weather in WeatherProbabilities)
            {
                cumulative += weather.Value;
                if (roll <= cumulative)
                {
                    return weather.Key;
                }
            }

            return "Unknown";
        }
    }
}
