﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Seasons
{
    public class Autumn : Season
    {
        public Autumn()
        {
            Name = "Autumn";
            daysInCurrentSeason = 0;
            WeatherProbabilities = new Dictionary<string, double>
            {
                { "Rainy", 0.5 },  // 50% na deszczowy dzień
                { "Cloudy", 0.3 }, // 30% na pochmurny dzień
                { "Sunny", 0.2 }   // 20% na słoneczny dzień
            };

        }
    }
}
