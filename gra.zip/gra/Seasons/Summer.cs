﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gra.Seasons
{
    public class Summer : Season
    {
        public Summer()
        {
            Name = "Summer";
            daysInCurrentSeason = 0;
            WeatherProbabilities = new Dictionary<string, double>
            {
                { "Sunny", 0.7 },  // 70% na słoneczny dzień
                { "Rainy", 0.2 },  // 20% na deszczowy dzień
                { "Stormy", 0.1 }  // 10% na burzowy dzień
            };
        }

    }
}
